=== Includes for WordPress ===
Plugin Name: Includes
Contributors: Chris Winters
Requires at least: 4.6
Requires PHP: 5.6
Tested up to: 5.4
Stable tag: 4.1.1
License: GNU GPLv3
License URI: /LICENSE

WordPress Plugin - Includes for WordPress - Include Content Anywhere!
