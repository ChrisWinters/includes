=== Includes for WordPress ===
Plugin Name: Includes
Contributors: Chris W.
Requires at least: 4.9
Requires PHP: 7.2
Tested up to: 6.1.1
Stable tag: 5.0.0
License: GNU GPLv3
License URI: /LICENSE

WordPress Plugin - Includes for WordPress - Include Content Anywhere!
